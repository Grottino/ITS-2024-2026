# How are we gonna make it (ideas):
 ## ⏱ 0:00 - 0:35 → Introduction
- Writing "please make a video for a english project about AI" #4 secondi
- zoom on click with sound effect #2 secondi
- black screen # 2 secondi
- video starts 
- drumroll hype con video che da piccolo ingrandisce #4 secondi
- albert learn to walk 00:00 - 00:14 (splash rumor at the end) while ale speak*
- black screen (Wanted di gta) ale:" yeah not like that" #2 sec
- Trackmania video # 2 sec
- simon talking ai graphic # 4 sec
- frankling talking ai graphic # 4 sec


## ⏱0:35 - 2:20 → Macro Topic: AI & Automation in Software Development
- AI can mimic the movements of the person who is speaking
- We dub the voice of the AI supported person that is speaking
- Sports car that does the same movements two or three times (Example of automation)
- Catching eventual issues 
- Creation of a software supported by AI that helps developers to not write all the software manually.(Development of the car's movements)
- AI optimizes the amount of time that is required to develop the software in an acceptable way.
- AI improves his efficiency and releases it in a smoother way.
- AI can be also used in the process of the code review before being released.It reports potential issues,enforces the code that has been written and can spot problems or weaknesses that can not immediately appear to a human's eye
- Briefly AI identifies and solves code issues and improves the reliability of the whole software.
- Ai and automation will improve the cycle of software development and they are speeding up the pace of it,improving the code quality and making operations more efficient.
-Both are in a continuing evolution and their impact will grow in a short period of time,making the industry more intelligent,faster and reliable.
They won't replace developers but they will help them to work smarter and faster in terms of efficiency,creating better products like a game or other products related with the tech's world.



## ⏱️ 2:20 - 4:05 → Micro Topic: AI-Driven Software Testing
Let's talk about AI-driven software testing—what it is, and why it matters.
AI in testing means using smart algorithms to automate the hardest parts of QA.
Instead of writing and maintaining tests by hand, AI can now:
Generate test cases automatically
Predict bugs before they happen
And even fix test scripts when the app changes
Let’s look at a few real-world examples.
First, there’s Generative Testing.
Tools like Testim or Functionize can scan your code and create test cases for you—so you spend less time on manual work.
Second, Self-Healing Tests.
If your UI changes, most tests break. But with tools like Mabl, AI detects those changes and updates the tests automatically.
Third, Visual Testing.
Platforms like Applitools compare screenshots and spot layout or design issues that might slip through manual checks.
And finally, Defect Prediction.
Tools like SonarQube AI analyze your code and highlight areas where bugs are most likely—so you can focus testing where it matters most.
In short, AI is making software testing faster, smarter, and a lot less painful.


## ⏱ 4:05 - 5:00 → Conclusion & Call to Action
- summary on the argument
- chatgpt saying "this is the work bla bla bla, if you want to adjust tell me" or something like that
- we writing "👍" and send
- title screen thank to amber # 10 sec


